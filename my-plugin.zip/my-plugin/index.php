<?php
    /* Silence is golden */